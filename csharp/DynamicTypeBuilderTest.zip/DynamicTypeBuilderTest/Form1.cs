﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

using Nequeo.Reflection;

namespace DynamicTypeBuilderTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Properties for type Size.
            DynamicPropertyValue[] dpvs = new DynamicPropertyValue[]
            {
                new DynamicPropertyValue("3XL", typeof(string), "5"),
                new DynamicPropertyValue("4XL", typeof(string), "5%"),
                new DynamicPropertyValue("5XL", typeof(string), "-10%")
            };

            // Properties for type Size0.
            DynamicPropertyValue[] dpvs0 = new DynamicPropertyValue[]
            {
                new DynamicPropertyValue("Medium", typeof(int), 1),
                new DynamicPropertyValue("Large", typeof(int), -3),
                new DynamicPropertyValue("XL", typeof(string), "10%")
            };

            // Properties for type Size1.
            DynamicPropertyValue[] dpvs1 = new DynamicPropertyValue[]
            {
                new DynamicPropertyValue("Shirt", typeof(string), "Do not like"),
                new DynamicPropertyValue("Shorts", typeof(double), 45.90),
                new DynamicPropertyValue("Show", typeof(int), 67),
                new DynamicPropertyValue("Sould", typeof(long), 34555),
            };

            // Create the module that will contain the types.
            DynamicTypeBuilder dtb = new DynamicTypeBuilder("SizesModule");

            // Create the Size, Size1, from the properties.
            var size = dtb.Create("Size", dpvs);
            var size0 = dtb.Create("Size0", dpvs0);
            var size1 = dtb.Create("Size1", dpvs1);

            // Add Size, Size1 to an array.
            object[] sizes = new object[] { size, size0, size1 };
            string typePropVale = "\r\n";

            // For easch object in the array.
            for (int i = 0; i < sizes.Length; i++)
            {
                // Get the name of the type.
                typePropVale += "\r\nType : " + sizes[i].GetType().Name + "\r\n";

                // Get all the properties in the type.
                PropertyInfo[] infos = sizes[i].GetType().GetProperties();

                // For each property in the type.
                foreach (PropertyInfo info in infos)
                    // Get the value assigned in the type.
                    typePropVale += info.Name + " = " + info.GetValue(sizes[i]).ToString() + "\r\n";
            }
            
            // Display the type name, property name and value.
            textBox1.Text = typePropVale.Trim();
        }
    }
}
