﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace UDPWebCanClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Connect()
        {
            pictureBox1.ClientSize = new Size(320, 240);

            // Create the client.
            IPEndPoint ee = new IPEndPoint(IPAddress.Any, 541);
            UdpClient u = new UdpClient(ee);

            // Create the state.
            UdpState s = new UdpState();
            s.e = ee;
            s.u = u;

            // Connect to the server.
            IPEndPoint server = new IPEndPoint(IPAddress.Any, 514);
            u.Connect("localhost", 514);

            // Start the begin receive callback.
            u.BeginReceive(new AsyncCallback(ReceiveCallback), s);

            // Send a connect request.
            byte[] connect = System.Text.Encoding.Default.GetBytes("connect");
            u.Send(connect, connect.Length);
        }

        public void ReceiveCallback(IAsyncResult ar)
        {
            // Get the client.
            UdpClient u = (UdpClient)((UdpState)(ar.AsyncState)).u;
            IPEndPoint e = (IPEndPoint)((UdpState)(ar.AsyncState)).e;

            // Get the image.
            Byte[] receiveBytes = u.EndReceive(ar, ref e);

            // Load the image into a stream.
            MemoryStream stream = new MemoryStream(receiveBytes);
            Image image = Image.FromStream(stream);

            // Add the image to the picture box.
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.Image = image;

            stream.Dispose();

            // Start a new receive request.
            u.BeginReceive(new AsyncCallback(ReceiveCallback), (UdpState)(ar.AsyncState));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Connect();
        }
    }

    public class UdpState
    {
        public UdpClient u { get; set; }
        public IPEndPoint e { get; set; }
    }
}
