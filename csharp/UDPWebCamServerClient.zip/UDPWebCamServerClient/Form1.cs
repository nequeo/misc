﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Concurrent;
using System.Net;
using System.IO;

namespace UDPWebCamServerClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int _clientCount = 0;
        bool _stopCapture = false;
        Nequeo.Net.UdpSingleServer _udpsingle = null;
        Nequeo.Media.FFmpeg.MediaDemux _demux = null;
        ConcurrentDictionary<IPEndPoint, Nequeo.Net.Sockets.IUdpSingleServer> _clients = null;


        private void button1_Click(object sender, EventArgs e)
        {
            StartServer();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StopServer();
        }

        private void StartServer()
        {
            // Create the server endpoint.
            Nequeo.Net.Sockets.MultiEndpointModel[] model = new Nequeo.Net.Sockets.MultiEndpointModel[]
                {
                // None secure.
                new Nequeo.Net.Sockets.MultiEndpointModel()
                {
                    Port = 514,
                    Addresses = new System.Net.IPAddress[]
                    {
                        System.Net.IPAddress.IPv6Any,
                        System.Net.IPAddress.Any
                    }
                },
                };

            if (_udpsingle == null)
            {
                // Create the UDP server.
                _udpsingle = new Nequeo.Net.UdpSingleServer(model);
                _udpsingle.OnContext += UDP_Single;
            }

            // Create the client collection.
            _clients = new ConcurrentDictionary<IPEndPoint, Nequeo.Net.Sockets.IUdpSingleServer>();
            _demux = new Nequeo.Media.FFmpeg.MediaDemux();

            // Start the server.
            _udpsingle.Start();

            _clientCount = 0;
            _stopCapture = false;

            // Start the capture process.
            CaptureAndSend();
        }

        private void StopServer()
        {
            _clientCount = 0;
            _stopCapture = true;

            if (_udpsingle != null)
            {
                _udpsingle.Stop();
                _udpsingle.Dispose();
            }
            _udpsingle = null;

            if (_demux != null)
                _demux.Close();

            _demux = null;
        }

        private void UDP_Single(object sender, Nequeo.Net.Sockets.IUdpSingleServer server, byte[] data, IPEndPoint endpoint)
        {
            string request = System.Text.Encoding.Default.GetString(data);

            if (request.ToLower().Contains("connect"))
                // Add the new client.
                _clients.GetOrAdd(endpoint, server);

            if (request.ToLower().Contains("disconnect"))
            {
                Nequeo.Net.Sockets.IUdpSingleServer removedServer = null;

                // Remove the existing client.
                _clients.TryRemove(endpoint, out removedServer);
            }
        }

        private async void CaptureAndSend()
        {
            await System.Threading.Tasks.Task.Run(() =>
            {
                if (_demux != null)
                {
                    // Open the web cam device.
                    _demux.OpenDevice("video=Integrated Webcam", true, false);

                    byte[] sound = null;
                    Bitmap[] image = null;

                    long audioPos = 0;
                    long videoPos = 0;

                    int count = 0;
                    KeyValuePair<IPEndPoint, Nequeo.Net.Sockets.IUdpSingleServer>[] clientCol = null;

                    // Most of the time one image at a time.
                    MemoryStream[] imageStream = new MemoryStream[10];
                    int imageStreamCount = 0;

                    // Within this loop you can place a check if there are any clients
                    // connected, and if none then stop capturing until some are connected.
                    while ((_demux.ReadFrame(out sound, out image, out audioPos, out videoPos) > 0) && !_stopCapture)
                    {
                        imageStreamCount = 0;
                        count = _clients.Count;

                        // If count has changed.
                        if (_clientCount != count)
                        {
                            // Get the collection of all clients.
                            _clientCount = count;
                            clientCol = _clients.ToArray();
                        }

                        // Has an image been captured.
                        if (image != null && image.Length > 0)
                        {
                            // Get all clients and send.
                            if (clientCol != null)
                            {
                                for (int i = 0; i < image.Length; i++)
                                {
                                    // Create a memory stream for each image.
                                    imageStream[i] = new MemoryStream();
                                    imageStreamCount++;

                                    // Save the image to the stream.
                                    image[i].Save(imageStream[i], System.Drawing.Imaging.ImageFormat.Jpeg);

                                    // Cleanup.
                                    image[i].Dispose();
                                }

                                // For each client.
                                foreach (KeyValuePair<IPEndPoint, Nequeo.Net.Sockets.IUdpSingleServer> client in clientCol)
                                {
                                    // For each image captured.
                                    for (int i = 0; i < imageStreamCount; i++)
                                    {
                                        // Send the image to this client.
                                        client.Value.SendTo(imageStream[i].ToArray(), client.Key);
                                        imageStream[i].Seek(0, SeekOrigin.Begin);
                                    }
                                }

                                for (int i = 0; i < imageStreamCount; i++)
                                    // Cleanup.
                                    imageStream[i].Dispose();
                            }
                        }
                    }
                }
            });
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CaptureToFile();
        }

        private void CaptureToFile()
        {
            Nequeo.Media.FFmpeg.MediaDemux demux = new Nequeo.Media.FFmpeg.MediaDemux();
            demux.OpenDevice("video=Integrated Webcam", true, false);

            // create instance of video writer
            Nequeo.Media.FFmpeg.VideoFileWriter writer = new Nequeo.Media.FFmpeg.VideoFileWriter();
            writer.Open(@"C:\Temp\Misc\ffmpeg_screen_capture_video.avi", demux.Width, demux.Height, demux.FrameRate, Nequeo.Media.FFmpeg.VideoCodec.MPEG4);

            byte[] sound = null;
            Bitmap[] image = null;

            List<Bitmap> video = new List<Bitmap>();
            long audioPos = 0;
            long videoPos = 0;

            int captureCount = 0;
            int captureNumber = 500;

            while ((demux.ReadFrame(out sound, out image, out audioPos, out videoPos) > 0) && captureCount < captureNumber)
            {
                if (image != null && image.Length > 0)
                {
                    captureCount++;

                    for (int i = 0; i < image.Length; i++)
                    {
                        writer.WriteVideoFrame(image[i]);
                        image[i].Dispose();
                    }
                }
            }

            writer.Close();
            demux.Close();
        }

        TestServer.WebcamWebSocketServer wsServer = null;
        private void button4_Click(object sender, EventArgs e)
        {
            wsServer = new TestServer.WebcamWebSocketServer();
            wsServer.UriList = new string[] { "http://localhost:2012/" };
            wsServer.Start();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            wsServer.StopCapture();
        }
    }
}
