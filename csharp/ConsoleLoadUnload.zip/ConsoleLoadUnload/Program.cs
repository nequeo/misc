﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleLoadUnload
{
    class Program
    {
        static void Main(string[] args)
        {
            Environment.Exit(0);
        }
    }

    public class Test
    {
        public int EntryPoint(int a, int b)
        {
            return a * b;

        }
    }
}
