﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoadUnload
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Nequeo.Reflection.AppDomianHost host = new Nequeo.Reflection.AppDomianHost(@"D:\Development\Version2015\Test\LoadUnload\ConsoleLoadUnload\bin\Debug");
            int ret = host.Instance.ExecuteMethod<int>("ConsoleLoadUnload", "ConsoleLoadUnload.Test", "EntryPoint", new object[] { (int)6, (int)6 });
            host.Unload();

            textBox1.Text = ret.ToString();
        }
    }
}
